package com.menudrinks.activity2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.Intent;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    ListView simpleList;
    String[] bookList = {"HarryPotter", "J.K.ROLLING", "376"};
    Button saveall;
    String[] sharedpref
            = { "Algorithms", "Data Structures",
            "Languages", "Interview Corner",
            "GATE", "ISRO CS",
            "UGC NET CS", "CS Subjects",
            "Web Technologies" };
    Button add;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        saveall = findViewById(R.id.saveall);

        simpleList = findViewById(R.id.sharedpref);
        ArrayAdapter<String> arr;
        arr = new ArrayAdapter<String>(this, R.layout.activity_main, R.id.textView, bookList);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_listview, R.id.textView, sharedpref);

        simpleList.setAdapter(arr);
        
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Listview.class);
                startActivity(intent);

            }

        });
    }}
// ListView simpleList;
//    String countryList[] = {"India", "China", "australia", "Portugle", "America", "NewZealand"};
//    // Button start;
//    @Override   protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);      setContentView(R.layout.activity_main);
//        simpleList = (ListView)findViewById(R.id.simpleListView);
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.activity_listview,R.id.textView, countryList);
//        simpleList.setAdapter(arrayAdapter);